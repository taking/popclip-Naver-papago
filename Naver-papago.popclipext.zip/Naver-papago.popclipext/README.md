# Naver Papago Translation PopClip Extension
-
### Introduction:
NAVER Translation Service Extension

=
    Credit: Extension made by Taking
    Contact me: ceo@taking.kr / https://taking.kr/blog/